<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ClienteModel;
use App\Models\UsuarioModel;
use App\Models\PedidoModel; 


class Cliente extends BaseController
{
    private $clienteModel;

    public function __construct(){
        $this->clienteModel = new ClienteModel();
    }

    public function Carrinho()
    {
        $session = session();
        $carrinho = $session->get('Carrinho') ?? [];

        echo view('_partials/header');
        echo view('cliente/Carrinho', ['Carrinho' => $carrinho]);
        echo view('_partials/footer');
    }

    public function adicionar($produto_id)
    {
        $session = session();
        $carrinho = $session->get('Carrinho') ?? [];

        $produtosDisponiveis = [
            //produtos da loja 
            1 => ['id' => 1, 'nome' => 'Creme Breylee Tratamento Acne E Espinhas Face 20g Anti-acne ', 'preco' => 59.99],
            2 => ['id' => 2, 'nome' => 'Creme Hidratante Para Mãos Flores E Vegetais - 100g', 'preco' => 19.90],
            3 => ['id' => 3, 'nome' => 'Perfume Guerlain Aqua Allegoria Nerolia Vetiver Edt 125 Ml - Carrefour', 'preco' => 89.90],
            4 => ['id' => 4, 'nome' => 'BasiQin Perfumizin Spray para Corpo e Cabelo CocoNut 150ml', 'preco' => 49.99],
            5 => ['id' => 5, 'nome' => '0-3M BABY GIRL Handmade Cotton Frock Shoes Hat Headband', 'preco' => 38.00],
            6 => ['id' => 6, 'nome' => 'Colete / Cropped Crochê | Elo7 Produtos Especiais', 'preco' => 100.00],
            7 => ['id' => 7, 'nome' => 'Kit Duo 30+ | Cestas Michelli', 'preco' => 30.00],
            8 => ['id' => 8, 'nome' => 'Sabonete Capim limão (glicerinado) uNeVie ', 'preco' => 20.00],
            
            //perfumes ok
            9 => ['id' => 9, 'nome' => 'Perfume Chloé Rose Naturelle Intense Eau de Parfum Refilável 100ml', 'preco' => 66.99],
            10 => ['id' => 10, 'nome' => 'Berber Blonde Sana Jardin perfume - a fragrância Feminino 2017', 'preco' => 99.99],
            11 => ['id' => 11, 'nome' => 'Perfume Guerlain Aqua Allegoria Nerolia Vetiver Edt 125 Ml - Carrefour', 'preco' => 89.99],
            12 => ['id' => 12, 'nome' => 'BasiQin Perfumizin Spray para Corpo e Cabelo CocoNut 150ml', 'preco' => 49.99],
            13 => ['id' => 13, 'nome' => 'Colônia Cacau e Gerânio 50 mL - Emanar Biocosméticos Naturais e sustentáveis', 'preco' => 39.99],
            14 => ['id' => 14, 'nome' => 'United Colors Of Benetton Dreams Green Amazonia Edt Perfume Feminino 80ml', 'preco' => 59.99],
            15 => ['id' => 15, 'nome' => 'Kit 3 Perfumes Spray 10ml Feminino - Notas Verdes Charmosas', 'preco' => 29.99],
            16 => ['id' => 16, 'nome' => 'Kit Arbo Forest: Deo Colônia 100ml + Body Spray 100ml Masculino', 'preco' => 79.99],

            //roupas 
            17 => ['id' => 17, 'nome' => 'Blusa em Crochê Feita à Mão - Dona Fabizoka', 'preco' => 150.00],
            18 => ['id' => 18, 'nome' => 'Conjunto Infantil Moda Praia Crochet Feito a Mão | Elo7', 'preco' => 120.00],
            19 => ['id' => 19, 'nome' => '0-3M BABY GIRL Handmade Cotton Frock Shoes Hat Headband', 'preco' => 38.00],
            20 => ['id' => 20, 'nome' => 'Colete / Cropped Crochê | Elo7 Produtos Especiais', 'preco' => 100.00],
            21 => ['id' => 21, 'nome' => 'Casaco Squares Crochê Feito a Mão | Elo7 Produtos Especiais', 'preco' => 200.00],
            22 => ['id' => 22, 'nome' => 'Kimono de Crochê | Elo7 Produtos Especiais', 'preco' => 180.00],
            23 => ['id' => 23, 'nome' => 'Colete em Crochê Feito à Mão - Dona Fabizoka', 'preco' => 130.00],
            24 => ['id' => 24, 'nome' => 'Saída de Praia – Azul- Crochê', 'preco' => 90.00],

            //sabonetes ok
            25 => ['id' => 25, 'nome' => 'Sabonete de Açafrão para Foliculite e Redução de Pelos', 'preco' => 25.00],
            26 => ['id' => 26, 'nome' => 'Sabonete Capim limão (glicerinado) uNeVie ', 'preco' => 20.00],
            27 => ['id' => 27, 'nome' => 'Kit Duo 30+ | Cestas Michelli', 'preco' => 30.00],
            28 => ['id' => 28, 'nome' => 'SABONETE VEGETAL ROMÃ - 120g - Vyvedas', 'preco' => 28.00],
            29 => ['id' => 29, 'nome' => 'SABONETE VEGETAL FLOR DE LARANJEIRA - 120g - Vyvedas', 'preco' => 28.00],
            30 => ['id' => 30, 'nome' => 'Sabonete de Amora - Hidratante e Calmante', 'preco' => 30.00],
            31 => ['id' => 31, 'nome' => 'Pack de mini sabonetes Aveia Artesanais Sustentáveis (20 grs) | Aromas da Villa', 'preco' => 35.00],
            32 => ['id' => 32, 'nome' => 'Sabonete Vegetal Positiv.a Limão Siciliano 85g - Sabonete', 'preco' => 32.00],
            
            //esfoliantes
            33 => ['id' => 33, 'nome' => 'Esfoliante Corporal Frutas Verdes 100ml - Renovação e Frescor | Chlorophylla', 'preco' => 29.90],
            34 => ['id' => 34, 'nome' => 'Esfoliante Facial Vegana Hidratação & Detox', 'preco' => 39.90],
            35 => ['id' => 35, 'nome' => 'Body Scrub Seaweed Bath Co. Detox Orange Cedar Scent 180ml', 'preco' => 49.90],
            36 => ['id' => 36, 'nome' => 'Nano Coffee Creme Esfoliante Enzimático e Gomagem Facial E Corporal 400g', 'preco' => 59.90],
            37 => ['id' => 37, 'nome' => 'Peeling de Hortelã Iluminador Adcos 100g', 'preco' => 69.90],
            38 => ['id' => 38, 'nome' => 'tonico facial pele oliosa 120ML', 'preco' => 49.90],
            39 => ['id' => 39, 'nome' => 'Esfoliante Enzimático Face E Corpo', 'preco' => 79.90],
            40 => ['id' => 40, 'nome' => 'Esfoliante De Laranja Para Rosto Ou Corpo', 'preco' => 30.99],

            //cremes/hidratantes
            41 => ['id' => 41, 'nome' => 'Baobá – Creme para as Mãos Lavanda & Palmarosa', 'preco' => 29.90],
            42 => ['id' => 42, 'nome' => 'Baobá – Hidratante Corporal Lavanda', 'preco' => 39.90],
            43 => ['id' => 43, 'nome' => 'Creme Breylee Tratamento Acne E Espinhas Face 20g Anti-acne ', 'preco' => 59.90],
            44 => ['id' => 44, 'nome' => 'Chlorophylla – Hidratante Corporal Antioxidante + Nutritivo Frutas Verdes ', 'preco' => 49.90],
            45 => ['id' => 45, 'nome' => 'Creme Hidratante Para Mãos Flores E Vegetais - 100g', 'preco' => 19.90],
            46 => ['id' => 46, 'nome' => 'BIOZENTHI ONFACE Sabonete Hidratante Facial Vegano Sem Glúten ', 'preco' => 29.90],
            47 => ['id' => 47, 'nome' => 'Kit 2x:loção Hidratante Corporal Lavanda Baunilha Alva 250g', 'preco' => 59.90],
            48 => ['id' => 48, 'nome' => 'Hidratante 37 Fator 5 - 180 Ml ', 'preco' => 39.90],

        ];

        if (array_key_exists($produto_id, $produtosDisponiveis)) {
            if (isset($carrinho[$produto_id])) {
                $carrinho[$produto_id]['quantidade'] += 1; // CORRIGIDO
            } else {
                $produto = $produtosDisponiveis[$produto_id];
                $produto['quantidade'] = 1;
                $carrinho[$produto_id] = $produto;
            }

            $session->set('Carrinho', $carrinho);
        }

        return redirect()->to(base_url('cliente/Carrinho'));
    }
    public function salvar_cartao()
{
    $dadosCartaoModel = new \App\Models\DadosCartaoModel();

    $data = [
        'nome_cartao' => $this->request->getPost('nome_cartao'),
        'numero_cartao' => $this->request->getPost('numero_cartao'),
        'validade' => $this->request->getPost('validade'),
        'cvv' => $this->request->getPost('cvv'),
    ];

    if ($dadosCartaoModel->insert($data)) {
        // Salvou com sucesso, redireciona a pagina pedido
        return redirect()->to(base_url('cliente/entrega_produto'));
    } else {
        //Se falhar, redireciona para o formulário com erro
        return redirect()->back()->with('error', 'Falha ao salvar dados do cartão.');
    }
}



public function confirmarPedido()
{
    $pedidoModel = new PedidoModel();

    $dados = [
        'nome'        => $this->request->getPost('nome'),
        'telefone'    => $this->request->getPost('telefone'),
        'email'       => $this->request->getPost('email'),
        'cep'         => $this->request->getPost('cep'),
        'rua'         => $this->request->getPost('rua'),
        'numero'      => $this->request->getPost('numero'),
        'complemento' => $this->request->getPost('complemento'),
        'bairro'      => $this->request->getPost('bairro'),
        'cidade'      => $this->request->getPost('cidade'),
        'estado'      => $this->request->getPost('estado'),
        'referencia'  => $this->request->getPost('referencia'),
        'observacoes' => $this->request->getPost('observacoes'),
    ];
    
    // Salva o pedido no banco
    $pedidoModel->insert($dados);

    // Agora pega seleciona os produtos comprados
    $session = session();
    $produtosComprados = $session->get('Carrinho') ?? [];

    // Passa os produtos para a sessão para exibir na confirmação
    $session->set('produtos_comprados', $produtosComprados);

    // Limpa o carrinho 
    $session->remove('Carrinho');

    // Redireciona para a página de confirmação do pedido
    return redirect()->to(base_url('cliente/pedidoConfirmado'))->with('mensagem', 'Pedido confirmado com sucesso!');
}

public function pedidoConfirmado()
{
    $session = session();
    $produtos = $session->get('produtos_comprados') ?? [];

    return view('cliente/pedido_confirmado', ['produtos' => $produtos]);
}
    public function limparCarrinho()
    {
        session()->remove('Carrinho');
        return redirect()->to('cliente/carrinho')->with('mensagem', 'Carrinho limpo com sucesso!');
    }
    public function obrigado()
{
    return view('obrigado');
}

    public function novo(){
        return view('cliente/cadastro');
    }

    public function login(){
        return view('cliente/login');
    }

    public function voltar(){
        return view('cliente/loja');
    }

    public function perfumes(){
        echo view('_partials/header');
        echo view('cliente/perfumes');
        echo view('_partials/footer');
    }
    public function contato_sucesso(){
        echo view('_partials/header');
        echo view('cliente/contato_sucesso');
        echo view('_partials/footer');
    }
    public function meusPedidos()
{
    $session = session();
    $usuarioId = $session->get('id');

    $pedidoModel = new \App\Models\PedidoModel();
    $pedidoItemModel = new \App\Models\PedidoItemModel();
    $produtoModel = new \App\Models\ProdutoModel();

    $pedidos = $pedidoModel->where('usuario_id', $usuarioId)->findAll();

    foreach ($pedidos as &$pedido) {
        $itens = $pedidoItemModel->where('pedido_id', $pedido['id'])->findAll();
        foreach ($itens as &$item) {
            $produto = $produtoModel->find($item['produto_id']);
            $item['nome'] = $produto['nome'] ?? 'Produto removido';
        }
        $pedido['itens'] = $itens;
    }

    return view('cliente/meusPedidos', ['pedidos' => $pedidos]);
}

    public function Roupas(){
        echo view('_partials/header');
        echo view('cliente/Roupas');
        echo view('_partials/footer');
    }
    public function entrega_produto(){
        echo view('_partials/header');
        echo view('cliente/entrega_produto');
        echo view('_partials/footer');
    }
   
   



    public function Sabonetes(){
        echo view('_partials/header');
        echo view('cliente/Sabonetes');
        echo view('_partials/footer');
    }

    public function Esfoliantes(){
        echo view('_partials/header');
        echo view('cliente/Esfoliantes');
        echo view('_partials/footer');
    }

    public function Cremes_Hidratantes(){
        echo view('_partials/header');
        echo view('cliente/Cremes_Hidratantes');
        echo view('_partials/footer');
    }

   
    public function historico()
{
    $data['cliente'] = $this->clienteModel->findAll();
    return view('cliente/historico', $data);
}


    public function pagar(){
        echo view('_partials/header');
        echo view('cliente/pagar');
        echo view('_partials/footer');
    }

    public function pagar_cartao(){
        echo view('_partials/header');
        echo view('cliente/pagar_cartao');
        echo view('_partials/footer');
    }

    public function processar_cartao(){
        echo view('_partials/header');
        echo view('cliente/processar_cartao');
        echo view('_partials/footer');
    }

    public function pagar_boleto(){
        echo view('_partials/header');
        echo view('cliente/pagar_boleto');
        echo view('_partials/footer');
    }

    public function gerar_boleto(){
        echo view('_partials/header');
        echo view('cliente/gerar_boleto');
        echo view('_partials/footer');
    }

    public function pagar_pix(){
        echo view('_partials/header');
        echo view('cliente/pagar_pix');
        echo view('_partials/footer');
    }

    public function Produto(){
        echo view('_partials/header');
        echo view('cliente/Produto');
        echo view('_partials/footer');
    }

    public function cadastro(){
        echo view('_partials/header');
        echo view('cliente/cadastro');
        echo view('_partials/footer');
    }

    public function inserir()
    {
        $dados = $this->request->getPost();

        if (!isset($dados['senha'], $dados['confirma_senha']) || $dados['senha'] !== $dados['confirma_senha']) {
            return redirect()->back()->withInput()->with('erro', 'As senhas não coincidem.');
        }

        unset($dados['confirma_senha']);
        $dados['senha'] = password_hash($dados['senha'], PASSWORD_DEFAULT);

        $this->clienteModel->save($dados);
        return redirect()->to('cliente/login')->with('sucesso', 'Cadastro realizado com sucesso, Faça login e visite nossa loja!!');
    }

    public function editar($id){
        $cliente = $this->clienteModel->find($id);
        echo view('_partials/header');
        echo view('cliente/edita', ['cliente' => $cliente]);
        echo view('_partials/footer');
    }
    
    public function atualizar($id){
        $cliente = $this->request->getPost();
        $this->clienteModel->update($id, $cliente);
        return redirect()->to('cliente/index');
    }

    public function excluir($id){
        $this->clienteModel->delete($id);
        return redirect()->to('cliente/index');
    }

    public function loja(){
        echo view('_partials/header');
        echo view('cliente/loja');
        echo view('_partials/footer');
    }
   
    
    public function compra(){
        echo view('_partials/header');
        echo view('cliente/compra');
        echo view('_partials/footer');
    }
   public function MeuPerfil()
{
    $session = session();

    // Checar se o cliente está logado
    if (!$session->get('logado')) {
        return redirect()->to(base_url('cliente/login'));
    }

    $data = [
        'nome'  => $session->get('nome'),
        'email' => $session->get('email'),
    ];

    return view('cliente/MeuPerfil', $data);
}

    public function index(){
        echo view('_partials/header');
        echo view('cliente/index');
        echo view('_partials/footer');
    }

    public function questionario(){
        echo view('_partials/header');
        echo view('cliente/questionario');
        echo view('_partials/footer');
    }

    public function tutorial(){
        echo view('_partials/header');
        echo view('cliente/tutorial');
        echo view('_partials/footer');
    }

    public function sobre(){
        echo view('_partials/header');
        echo view('cliente/sobre');
        echo view('_partials/footer');
    }

    public function serviços(){
        echo view('_partials/header');
        echo view('cliente/serviços');
        echo view('_partials/footer');
    }

    public function contato(){
        echo view('_partials/header');
        echo view('cliente/contato');
        echo view('_partials/footer');
    }
  

    public function resultado_quiz()
    {
        $respostas_certas = [
            'q1' => 'certo',
            'q2' => 'certo',
            'q3' => 'certo',
            'q4' => 'certo',
            'q5' => 'certo',
            'q6' => 'certo',
            'q7' => 'certo',
        ];
    
        $post = $this->request->getPost();
    
        $acertos = 0;
        foreach ($respostas_certas as $pergunta => $resposta_certa) {
            if (isset($post[$pergunta]) && $post[$pergunta] === $resposta_certa) {
                $acertos++;
            }
        }
    
        
        echo "Você acertou $acertos de 7 perguntas!";
    }
    


    

    public function irloja(){
        return redirect()->to('cliente/loja');
    }
    

public function autenticar()
{
    $email = $this->request->getPost('email');
    $senha = $this->request->getPost('senha');

   
    $cliente = $this->clienteModel->where('email', $email)->first();

  
    if ($cliente && password_verify($senha, $cliente['senha'])) {
      
        $session = session();
        $session->set([
            'cliente_id' => $cliente['id'], 
            'nome'       => $cliente['nome'],  
            'email'      => $cliente['email'],  
            'logado'     => true, 
        ]);

       
        return redirect()->to(base_url('cliente/loja')); 
    } else {
       
        session()->setFlashdata('erro', 'Email ou senha incorretos.');
        return redirect()->to(base_url('cliente/login'));
    }
}



}