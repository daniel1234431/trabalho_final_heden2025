<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class CarrinhoController extends Controller
{
   
    public function index()
    {
       
        $carrinho = session()->get('carrinho') ?? [];
        echo view('cliente/Carrinho', ['carrinho' => $carrinho]);
    }

   
    public function adicionar($produtoId)
    {
       
        $produto = $this->getProdutoPorId($produtoId);
        
        if ($produto) {
           
            $carrinho = session()->get('carrinho') ?? [];

            
            $carrinho[] = [
                'id' => $produto['id'],
                'nome' => $produto['nome'],
                'preco' => $produto['preco'],
                'quantidade' => 1 
            ];

            
            session()->set('carrinho', $carrinho);
        }

       
        return redirect()->to('/cliente/carrinho');
    }

    
    private function getProdutoPorId($id)
    {
        
        $produtos = [
            1 => ['id' => 1, 'nome' => 'Perfume', 'preco' => 100],
            2 => ['id' => 2, 'nome' => 'Camiseta', 'preco' => 50],
            3 => ['id' => 3, 'nome' => 'Sabonete', 'preco' => 25],
            4 => ['id' => 4, 'nome' => 'Esfoliante', 'preco' => 30],
            
        ];

        return $produtos[$id] ?? null;
    }

    public function realizarCompra()
    {
        $pedidoModel = new PedidoModel();

        
        $dadosCompra = [
            'cliente_id'   => session()->get('usuario_logado')['id'], 
            'produto_nome' => $this->request->getPost('produto_nome'), 
            'data_compra'  => date('Y-m-d H:i:s'), 
            'status'        => 'Pendente', 
            'nome'          => $this->request->getPost('nome'),
            'telefone'      => $this->request->getPost('telefone'),
            'email'         => $this->request->getPost('email'),
            'cep'           => $this->request->getPost('cep'),
            'rua'           => $this->request->getPost('rua'),
            'numero'        => $this->request->getPost('numero'),
            'complemento'   => $this->request->getPost('complemento'),
            'bairro'        => $this->request->getPost('bairro'),
            'cidade'        => $this->request->getPost('cidade'),
            'estado'        => $this->request->getPost('estado'),
            'referencia'    => $this->request->getPost('referencia'),
            'observacoes'   => $this->request->getPost('observacoes')
        ];

       
        if ($pedidoModel->save($dadosCompra)) {
            return redirect()->to(base_url('cliente/perfil'))->with('success', 'Compra realizada com sucesso!');
        } else {
            return redirect()->to(base_url('cliente/perfil'))->with('error', 'Erro ao realizar a compra.');
        }
    }
}

