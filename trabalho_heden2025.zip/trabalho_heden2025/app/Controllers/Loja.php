<?php

namespace App\Controllers;

class Loja extends BaseController
{
    public function index()
    {
        return view('loja'); 
    }
}