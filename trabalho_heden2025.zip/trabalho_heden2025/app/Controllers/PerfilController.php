<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class PerfilController extends Controller
{
    public function index()
    {
        // Exibe o formulário
        return view('perfil_form');
    }

    public function upload()
    {
        $foto = $this->request->getFile('foto');

        if ($foto && $foto->isValid() && !$foto->hasMoved()) {
            $ext = $foto->getExtension();
            $permitidos = ['jpg', 'jpeg', 'png', 'gif'];

            if (in_array(strtolower($ext), $permitidos)) {
                $novoNome = $foto->getRandomName();
                $foto->move(WRITEPATH . 'uploads', $novoNome);  // Salva em writable/uploads

                return "Upload realizado com sucesso!<br>" . 
                       "<img src='" . base_url('writable/uploads/' . $novoNome) . "' alt='Foto' style='max-width:200px;' />";
            } else {
                return "Formato de arquivo não permitido.";
            }
        } else {
            return "Erro no upload da imagem.";
        }
    }
}
