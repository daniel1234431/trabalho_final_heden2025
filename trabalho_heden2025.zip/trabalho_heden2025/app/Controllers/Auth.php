<?php

namespace App\Controllers;

use App\Models\ClienteModel;

class Auth extends BaseController
{
    public function login()
    {
        return view('login_form');
    }

    public function autenticar()
    {
        $nome  = $this->request->getPost('nome');
        $email = $this->request->getPost('email');
        $senha = $this->request->getPost('senha');

        $usuarioModel = new UsuarioModel();

        // Supondo que você tenha um método "verificarLogin"
        $usuario = $usuarioModel->verificarLogin($email, $senha);

        if ($usuario) {
            session()->set('usuario_logado', $usuario);
            return redirect()->to(base_url('cliente/index'));
        } else {
            session()->setFlashdata('erro', 'Email ou senha incorretos.');
            return redirect()->to(base_url('cliente/login'));
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/auth/login');
    }
}