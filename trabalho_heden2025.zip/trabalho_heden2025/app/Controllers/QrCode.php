<?php

namespace App\Controllers;

use Endroid\QrCode\Builder\Builder;
use Endroid\QrCode\Writer\PngWriter;

class QrCode extends BaseController
{
    public function gerar()
    {
        $qrCode = Builder::create()
            ->writer(new PngWriter())
            ->data('https://seudominio.com/exemplo') // link ou dado que você quer codificar
            ->size(300)
            ->margin(10)
            ->build();

        // Retorna a imagem diretamente
        return $this->response
            ->setHeader('Content-Type', $qrCode->getMimeType())
            ->setBody($qrCode->getString());
    }
}
