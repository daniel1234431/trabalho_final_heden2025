<?php

namespace App\Models;

use CodeIgniter\Model;

class PedidoItemModel extends Model
{
    protected $table = 'entrega_pedido';
    protected $primaryKey = 'id';
    protected $allowedFields = ['id', 'produto_id', 'quantidade', 'preco_unitario'];
}
