<?php

namespace App\Models;

use CodeIgniter\Model;

class UsuarioModel extends Model
{
    protected $table = 'cliente'; 
    protected $primaryKey = 'id';
    protected $allowedFields = ['nome', 'email', 'senha'];

    public function verificarLogin($email, $senha)
    {
        return $this->where('email', $email)
                    ->where('senha', md5($senha))
                    ->first();
    }
}