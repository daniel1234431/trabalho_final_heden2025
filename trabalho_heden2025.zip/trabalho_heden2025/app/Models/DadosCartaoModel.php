<?php

namespace App\Models;

use CodeIgniter\Model;

class DadosCartaoModel extends Model
{
    protected $table = 'dados_cartao';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nome_cartao', 'numero_cartao', 'validade', 'cvv'];
    

    protected $useTimestamps = false;
}