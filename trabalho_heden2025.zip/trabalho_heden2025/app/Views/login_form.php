<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Cadastro</title>

  <script src="https://unpkg.com/lucide@latest"></script>
  <style>
    body {
      background-color:#e8f5e9;
      font-family: Arial, sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }
    /* Animação de tremer */
    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      25% { transform: translateX(-5px); }
      75% { transform: translateX(5px); }
    }

    /* Animação de deslizar para baixo */
    @keyframes slideDown {
      from { transform: translateY(-100%); }
      to { transform: translateY(0); }
    }
    .form-container {
      background-color: #ffffff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      width: 320px;
    }

    .form-container h2 {
      text-align: center;
      margin-bottom: 20px;
      color: #00796b;
    }

    .form-group {
      margin-bottom: 15px;
    }

    .form-group label {
      display: block;
      margin-bottom: 5px;
      color: #004d40;
    }

    .form-group input {
      width: 100%;
      padding: 10px;
      border: 1px solid #b2dfdb;
      border-radius: 8px;
      box-sizing: border-box;
    }

    .btn-login {
      width: 100%;
      padding: 12px;
      background-color: #00796b;
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-size: 16px;
      transition: background-color 0.3s ease;
    }

    .btn-login:hover {
      background-color: #004d40;
    }

    .btn-voltar {
      display: block;
      text-align: center;
      margin-top: 15px;
      color: #00796b;
      text-decoration: none;
      font-weight: bold;
    }

    .header {
      background-color: var(--verde-escuro);
      position: fixed;
      top: 0;
      width: 100%;
      z-index: 1000;
      box-shadow: 0 4px 12px var(--sombra);
      animation: slideDown 0.5s ease-out;
    }

    .nav-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 20px;
      max-width: 1400px;
      margin: 0 auto;
    }

    .logo {
      display: flex;
      align-items: center;
      color: var(--branco);
      text-decoration: none;
      font-weight: bold;
      font-size: 1.5rem;
      padding: 15px 0;
    }

    .logo img {
      height: 40px;
      margin-right: 10px;
    }

    .menu-toggle {
      display: none;
      background: none;
      border: none;
      color: var(--branco);
      font-size: 1.5rem;
      cursor: pointer;
    }

    .menu-items {
      display: flex;
      list-style: none;
      margin: 0;
      padding: 0;
    }

    .menu-items li {
      position: relative;
    }

    .menu-items a {
      color: var(--branco);
      text-decoration: none;
      padding: 20px 15px;
      display: block;
      font-weight: 500;
      transition: all 0.3s ease;
      position: relative;
    }

    .menu-items a:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }

    .menu-items a::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      width: 0;
      height: 3px;
      background: var(--branco);
      transition: all 0.3s ease;
      transform: translateX(-50%);
    }

    .menu-items a:hover::after {
      width: 80%;
    }

    .menu-items i {
      margin-right: 8px;
    }

    /* Conteúdo Principal */
    .main-content {
      padding-top: 80px;
      padding-bottom: 60px;
    }

    /* Restante do seu CSS existente */
    .container-wrapper {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 30px;
      margin: 40px auto;
      max-width: 1400px;
      transition: 
        background-color 0.3s ease, 
        transform 0.2s ease, 
        box-shadow 0.3s ease, 
        filter 0.3s ease;
      box-shadow: 0 4px 6px rgba(0,0,0,0.9);
      animation: fadeIn 0.6s ease-in-out;
    }

    .container {
      flex: 1 1 400px;
      max-width: 500px;
      background-color: rgba(255, 255, 255, 0.85);
      border-radius: 15px;
      padding: 30px;
      box-shadow: 0 6px 10px rgba(0,0,0,0.3);
      animation: fadeIn 0.6s ease-in-out;
      transition: 
        background-color 0.3s ease, 
        transform 0.2s ease, 
        box-shadow 0.3s ease, 
        filter 0.3s ease;
    }

    .titulo1 {
      font-size: 24px;
      color: var(--verde-escuro);
      margin-bottom: 15px;
    }

    .btn {
      background-color: var(--verde-escuro);
      color: white;
      padding: 12px 24px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-weight: bold;
      text-decoration: none;
      display: inline-block;
      transition: all 0.3s ease;
      box-shadow: 0 4px 6px rgba(0,0,0,0.3);
      animation: fadeIn 0.6s ease-in-out;
      position: relative;
      overflow: hidden;
    }

    .btn:hover {
      background-color: var(--verde-esmeralda);
      transform: translateY(-3px);
      box-shadow: 0 6px 12px rgba(0,0,0,0.2);
      animation: bounce 0.5s ease;
    }

    .btn:active {
      transform: translateY(1px);
    }

    .btn::after {
      content: '';
      position: absolute;
      top: 50%;
      left: 50%;
      width: 5px;
      height: 5px;
      background: rgba(255, 255, 255, 0.5);
      opacity: 0;
      border-radius: 100%;
      transform: scale(1, 1) translate(-50%);
      transform-origin: 50% 50%;
    }

    .button-container .btn {
      width: 100%;
      margin-top: 15px;
    }

    
    form input[type="text"],
    form input[type="email"],
    form input[type="password"] {
      padding: 12px;
      width: 100%;
      border-radius: 8px;
      border: 1px solid #ccc;
      margin-bottom: 15px;
      transition: all 0.3s ease;
      box-shadow: 0 2px 4px rgba(0,0,0,0.9);
    }

    /* Rodapé */
    .footer {
      text-align: center;
      padding: 20px;
      font-weight: bold;
      color: white;
      background-color: var(--verde-escuro);
      border-top: 4px solid #81C784;
      animation: fadeIn 0.8s ease-in-out;
      position: fixed;
      bottom: 0;
      width: 100%;
    }

   
    @media (max-width: 768px) {
      .menu-toggle {
        display: block;
      }

      .menu-items {
        
        top: 70px;
        left: -100%;
        width: 80%;
        height: calc(100vh - 70px);
        background-color: var(--verde-escuro);
        flex-direction: column;
        transition: all 0.5s ease;
        box-shadow: 2px 0 5px var(--sombra);
      }

      .menu-items.active {
        left: 0;
      }

      .menu-items li {
        width: 100%;
      }

      .menu-items a {
        padding: 15px 20px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      }

      .main-content {
        padding-top: 70px;
      }

      .container {
        margin: 15px;
        padding: 20px;
      }
    }
    :root {
      --verde-esmeralda: #43A047;
      --verde-principal: #2E7D32;
      --verde-escuro: #014421;
      --branco: #FFFFFF;
      --sombra: rgba(0,0,0,0.2);
    } 
    p{
      font-size: 16px;
      color: var(--verde-escuro);
      margin-top: 10px;
      text-align:center;
    }
  </style>
</head>
<body>
<!-- Menu -->
<header class="header">
    <div class="nav-container">
        <a href="<?=base_url('cliente/index')?>" class="logo">
            <i data-lucide="leaf"></i> Artesana
        </a>
        
        <button class="menu-toggle" id="menuToggle">
            <i data-lucide="menu"></i>
        </button>
        
        <ul class="menu-items" id="menuItems">
            <li><a href="<?=base_url('cliente/index')?>"><i data-lucide="home"></i> Início</a></li>
            <li><a href="<?=base_url('cliente/sobre')?>"><i data-lucide="info"></i> Sobre</a></li>
            <li><a href="<?=base_url('cliente/serviços')?>"><i data-lucide="briefcase"></i> Serviços</a></li>
            <li><a href="<?=base_url('cliente/loja')?>"><i data-lucide="shopping-bag"></i> Produtos</a></li>
            <li><a href="<?=base_url('cliente/contato')?>"><i data-lucide="mail"></i> Contato</a></li>
        </ul>
    </div>
</header>

  <div class="form-container">
    <h2>Login</h2>
    <form action="<?= base_url('cliente/autenticar') ?>" method="post">

      <div class="form-group">
        <label for="nome">Nome</label>
        <input type="text" id="nome" name="nome" required />
      </div>
      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required />
      </div>
      <div class="form-group">
        <label for="senha">Senha</label>
        <input type="password" id="senha" name="senha" required />
      </div>
      <button type="submit" class="btn-login" href="<?=base_url('cliente/loja')?>">Entrar</button>
      <a href="<?=base_url('cliente/cadastro')?>" class="btn-voltar">Voltar</a>

      <p>Ainda não tem uma conta? <a href="<?=base_url('cliente/cadastro')?>">Cadastre-se</a></p>
      <p>Esqueceu a senha? <a href="<?=base_url('cliente/nao_implementado')?>">Recuperar senha</a></p>

    </form>
  </div>
  <script>
    lucide.createIcons();

   
    document.getElementById("menuToggle").addEventListener("click", function () {
        document.getElementById("menuItems").classList.toggle("active");
    });
</script>
<script>
  lucide.replace();
</script>
</body>
</html>
