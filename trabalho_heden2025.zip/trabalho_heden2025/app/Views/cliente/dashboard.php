

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Dashboard</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>" />
</head>
<body>
    <div class="dashboard-container">
        <h2>Bem-vindo, <?= esc(session()->get('user_email')) ?>!</h2>
        
        <nav class="dashboard-nav">
            <a href="<?= site_url('profile') ?>">Meu Perfil</a>
            <a href="<?= site_url('auth/logout') ?>">Sair</a>
        </nav>
        
        <div class="dashboard-content">
            <p></p>
        </div>
    </div>
</body>
</html>