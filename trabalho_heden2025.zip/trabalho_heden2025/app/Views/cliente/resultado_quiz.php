<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Resultado do Quiz</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #e8f5e9;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }

    .resultado {
      background-color: #ffffff;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      text-align: center;
      max-width: 500px;
    }

    .resultado h2 {
      color: #2e7d32;
    }
  </style>
</head>
<body>
<h2>Você acertou <?= esc($acertos) ?> de 7 perguntas!</h2>


<?php
$respostas_corretas = [
  'q1' => 'a',
  'q2' => 'b',
  'q3' => 'c',
  'q4' => 'a',
  'q5' => 'd',
  'q6' => 'b',
  'q7' => 'c',
];

$acertos = 0;
foreach ($respostas_corretas as $questao => $resposta_correta) {
  if (isset($_POST[$questao]) && $_POST[$questao] === $resposta_correta) {
    $acertos++;
  }
}
?>




  <div class="resultado">
    <h2>Você acertou <?= $acertos ?> de 7 perguntas!</h2>
    <?php if ($acertos >= 5): ?>
      <p>Parabéns! Aproveite seu desconto de 70%!</p>
    <?php else: ?>
      <p>Você pode tentar novamente para melhorar seu resultado!</p>
    <?php endif; ?>
    <div>
    <?= anchor('Cliente/questionario', 'Tentar Novamente', ['class' => 'btn btn-primary btn-transition', 'data-url' => base_url('Cliente/resultado_quiz')]) ?>
    </div>
  </div>

  <?php
$respostas_corretas = [
  'q1' => 'a',
  'q2' => 'b',
  'q3' => 'c',
  'q4' => 'a',
  'q5' => 'd',
  'q6' => 'b',
  'q7' => 'c',
];

$acertos = 0;
foreach ($respostas_corretas as $questao => $resposta_correta) {
  if (isset($_POST[$questao]) && $_POST[$questao] === $resposta_correta) {
    $acertos++;
  }
}
?>

<div class="resultado">
  <h2>Você acertou <?= $acertos ?> de 7 perguntas!</h2>
  <?php if ($acertos >= 5): ?>
    <p>Parabéns! Aproveite seu desconto de 70%!</p>
  <?php else: ?>
    <p>Você pode tentar novamente para melhorar seu resultado!</p>
  <?php endif; ?>
  <div>
    <a href="<?= base_url('cliente/questionario') ?>" class="btn btn-primary btn-transition">Tentar Novamente</a>
  </div>
</div>

</body>
</html>
