<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Quiz de Sustentabilidade</title>
  <style>
   body {
  font-family: 'Arial', sans-serif;
  background-color: #dbece6;
  margin: 0;
  padding: 0;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
}

header {
  background-color: #2E7D32;
  padding: 20px;
  text-align: center;
  color: white;
}

header nav a {
  color: white;
  margin: 0 15px;
  text-decoration: none;
  font-weight: bold;
}

header nav a:hover {
  text-decoration: underline;
}

.quiz-container {
  margin-top: 120px; /* Aumentei o valor de margin-top */
  background-color: #fff;
  max-width: 600px;
  width: 90%;
  padding: 30px;
  border-radius: 15px;
  box-shadow: 0 8px 16px rgba(0,0,0,0.1);
  animation: fadeIn 0.5s ease-in-out;
}

h1 {
  text-align: center;
  color: #2e7d32;
  margin-bottom: 20px;
}

.question {
  margin-bottom: 20px;
}

.question h3 {
  font-size: 18px;
  margin-bottom: 10px;
  color: #333;
}

.question label {
  display: block;
  margin-bottom: 8px;
}

.submit-btn {
  display: block;
  width: 100%;
  background: #4CAF50;
  color: white;
  border: none;
  padding: 12px;
  font-size: 16px;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.3s;
}

.submit-btn:hover {
  background: #388e3c;
}

.button-container {
  text-align: center;
  margin-top: 15px;
}

.footer {
  text-align: center;
  padding: 20px;
  font-weight: bold;
  color: white;
  background-color: #2E7D32;
  border-top: 4px solid #81C784;
  animation: fadeIn 0.8s ease-in-out;
  position: fixed;
  bottom: 0;
  width: 100%;
}

/* Ajustes no input */
form input[type="radio"] {
  margin-right: 10px;
}

form input[type="email"],
form input[type="text"] {
  padding: 12px;
  width: 100%;
  border-radius: 8px;
  border: 1px solid #ccc;
  margin-bottom: 15px;
  transition: all 0.3s ease;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

/* Responsivo */
@media (max-width: 768px) {
  .quiz-container {
    margin-top: 120px; /* Ajuste para garantir o afastamento também em dispositivos móveis */
    width: 100%;
  }
  
  h1 {
    font-size: 24px;
  }

  .question h3 {
    font-size: 16px;
  }
  
  form input[type="email"],
  form input[type="text"] {
    font-size: 14px;
  }
  
  .submit-btn {
    font-size: 14px;
  }
}

/* Animações */
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

/* Melhorias no Header */
.header {
  position: fixed;
  top: 0;
  width: 100%;
  z-index: 1000;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
  padding: 15px;
}

.nav-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  max-width: 1200px;
  margin: 0 auto;
}

.menu-items {
  display: flex;
}

.menu-items li {
  list-style: none;
}

.menu-items a {
  color: white;
  text-decoration: none;
  padding: 10px 15px;
  display: block;
  font-weight: bold;
  transition: background-color 0.3s ease;
}

.menu-items a:hover {
  background-color: rgba(255, 255, 255, 0.2);
}

.menu-toggle {
  display: none;
}

/* Ajustes no botão de envio */
.submit-btn {
  background: #4CAF50;
  color: white;
  padding: 12px 20px;
  border-radius: 8px;
  cursor: pointer;
  font-weight: bold;
  border: none;
  width: 100%;
  box-shadow: 0 6px 10px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
}

.submit-btn:hover {
  background-color: #388e3c;
  transform: scale(1.05);
}

.submit-btn:active {
  transform: scale(1);
}

/* Ajustando o layout dos inputs */
.question label {
  margin: 8px 0;
  font-size: 16px;
}

footer {
  text-align: center;
  background-color: #2E7D32;
  color: white;
  padding: 10px;
  margin-top: 20px;
}

/* Animação no fade-in */
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

  </style>
</head>
<body>

  <header class="header">
    <div class="nav-container">
      <!-- Logo -->
     <a href="<?=base_url('cliente/index')?>" class="logo">
        <i data-lucide="leaf"></i> Artesana
      </a>

      <!-- Botão do menu mobile -->
      <button class="menu-toggle" id="menuToggle">
        <i data-lucide="menu"></i>
      </button>

      <!-- Itens do menu -->
      <ul class="menu-items" id="menuItems">
       
        <li><a href="<?=base_url('cliente/index')?>"><i data-lucide="home"></i> Início</a></li>
        <li><a href="<?=base_url('cliente/sobre')?>"><i data-lucide="info"></i> Sobre</a></li>
        <li><a href="<?=base_url('cliente/serviços')?>"><i data-lucide="briefcase"></i> Serviços</a></li>
        <li><a href="<?=base_url('cliente/loja')?>"><i data-lucide="shopping-bag"></i> Produtos</a></li>
        <li><a href="<?=base_url('cliente/contato')?>"><i data-lucide="mail"></i> Contato</a></li>
       
  </header>

<div class="quiz-container">
  <h1>Quiz: Sustentabilidade</h1>
  <form id="quiz-form" method="post" action="<?= base_url('cliente/resultado_quiz') ?>">

    <?php
    $perguntas = [
      '1. O que significa desenvolvimento sustentável?' => [
        'Crescimento econômico ilimitado' => 'errado',
        'Utilizar os recursos naturais de forma consciente' => 'certo',
        'Expandir cidades e indústrias' => 'errado'
      ],
      '2. Qual desses materiais é reciclável?' => [
        'Plástico' => 'certo',
        'Comida' => 'errado',
        'Tecido sujo' => 'errado'
      ],
      '3. Qual é a principal fonte de energia renovável no Brasil?' => [
        'Carvão mineral' => 'errado',
        'Hidrelétrica' => 'certo',
        'Petróleo' => 'errado'
      ],
      '4. Qual das alternativas reduz a emissão de CO₂?' => [
        'Usar mais o carro' => 'errado',
        'Plantar árvores' => 'certo',
        'Desmatar florestas' => 'errado'
      ],
      '5. O que é a compostagem?' => [
        'Método de queima de lixo' => 'errado',
        'Processo de transformar resíduos orgânicos em adubo' => 'certo',
        'Armazenamento de lixo em lixões' => 'errado'
      ],
      '6. Qual ação ajuda a preservar a água potável?' => [
        'Lavar calçadas com mangueira' => 'errado',
        'Consertar vazamentos' => 'certo',
        'Deixar torneiras abertas' => 'errado'
      ],
      '7. O que significa "pegada de carbono"?' => [
        'O número de pegadas em uma trilha' => 'errado',
        'Quantidade de carbono emitida por uma pessoa, empresa ou produto' => 'certo',
        'O tipo de solo afetado pela poluição' => 'errado'
      ]
    ];

    $i = 1;
    foreach ($perguntas as $titulo => $respostas):
    ?>
    <div class="question">
      <h3><?= $i . '. ' . $titulo ?></h3>
      <?php foreach ($respostas as $texto => $valor): ?>
        <label>
          <input type="radio" name="q<?= $i ?>" value="<?= $valor ?>"> <?= $texto ?>
        </label>
      <?php endforeach; ?>
    </div>
    <?php $i++; endforeach; ?>

    <!-- Início do formulário -->
    <form action="<?= site_url('quiz/avaliar') ?>" method="post">
  <!-- Perguntas e alternativas aqui -->

  <div class="text-center mt-4">
    <button type="submit" class="btn btn-success">Enviar Respostas</button>
  </div>
</form>
</form>

  </form>
</div>

<script>
  document.getElementById('quiz-form').addEventListener('submit', function (e) {
    const requiredQuestions = ['q1', 'q2', 'q3', 'q4', 'q5', 'q6', 'q7'];
    let allAnswered = true;

    for (const question of requiredQuestions) {
      const options = document.getElementsByName(question);
      const isChecked = Array.from(options).some(option => option.checked);
      if (!isChecked) {
        allAnswered = false;
        break;
      }
    }

    if (!allAnswered) {
      e.preventDefault();
      alert("Por favor, responda todas as perguntas antes de enviar.");
    }
  });
</script>


</body>
</html>