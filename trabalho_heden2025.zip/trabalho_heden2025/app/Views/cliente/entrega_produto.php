<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Formulário de Entrega de Pedido</title>
  <style>
    :root {
      --verde-esmeralda: #43A047;
      --verde-principal: #2E7D32;
      --verde-escuro: #014421;
      --branco: #FFFFFF;
      --sombra: rgba(0,0,0,0.2);
    }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 30px;
      background-color: #f5f5f5;
      color: #333;
    }

    form {
      background-color: #fff;
      padding: 30px 40px;
      border-radius: 12px;
      max-width: 600px;
      margin: auto;
      box-shadow: 0 6px 15px rgba(0,0,0,0.1);
      transition: box-shadow 0.3s ease;
    }

    form:hover {
      box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    }

    label {
      display: block;
      margin-top: 20px;
      font-weight: 600;
      color: var(--verde-principal);
    }

    input, textarea, select {
      width: 100%;
      padding: 12px 15px;
      margin-top: 6px;
      border-radius: 8px;
      border: 1.8px solid #ccc;
      font-size: 1rem;
      font-weight: 500;
      color: #444;
      transition: border-color 0.3s ease, box-shadow 0.3s ease;
      box-shadow: inset 0 1px 3px rgba(0,0,0,0.05);
      font-family: inherit;
    }

    input:focus, textarea:focus, select:focus {
      outline: none;
      border-color: var(--verde-esmeralda);
      box-shadow: 0 0 8px var(--verde-esmeralda);
      background-color: #f9fff9;
    }

    textarea {
      resize: vertical;
      min-height: 100px;
    }

    button {
      margin-top: 25px;
      padding: 12px 28px;
      font-size: 1.1rem;
      font-weight: 700;
      border: none;
      border-radius: 30px;
      cursor: pointer;
      transition: background-color 0.4s ease, box-shadow 0.3s ease;
      box-shadow: 0 4px 10px rgba(46, 125, 50, 0.3);
      font-family: inherit;
    }

    /* Botão principal: Confirmar */
    .btn00 {
      background-color: var(--verde-esmeralda);
      color: var(--branco);
    }

    .btn00:hover {
      background-color: var(--verde-principal);
      box-shadow: 0 6px 15px rgba(46, 125, 50, 0.6);
    }

    /* Botão secundário: Cancelar */
    .btn01 {
      background-color: #e0e0e0;
      color: #555;
      margin-left: 15px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      transition: background-color 0.3s ease, color 0.3s ease;
    }

    .btn01:hover {
      background-color: #c8c8c8;
      color: #222;
    }

    /* Container dos botões alinhados ao centro */
    .btn-container {
      text-align: center;
    }

    /* Texto da observação */
    #passwordHelpBlock {
      margin-top: 12px;
      font-size: 0.9rem;
      color: #666;
      font-style: italic;
      font-family: inherit;
    }

    h2 {
      text-align: center;
      color: #333;
      font-family: inherit;
    }

    /* Header e menu */

    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      25% { transform: translateX(-5px); }
      75% { transform: translateX(5px); }
    }

    @keyframes slideDown {
      from { transform: translateY(-100%); }
      to { transform: translateY(0); }
    }

    html, body {
      min-height: 100vh;
      height: 100%;
      margin: 0;
      padding: 0;
    }

    .header {
      background-color: var(--verde-escuro);
      position: fixed;
      top: 0;
      width: 100%;
      z-index: 1000;
      box-shadow: 0 4px 12px var(--sombra);
      animation: slideDown 0.5s ease-out;
    }

    .nav-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 20px;
      max-width: 1400px;
      margin: 0 auto;
    }

    .logo {
      display: flex;
      align-items: center;
      color: var(--branco);
      text-decoration: none;
      font-weight: bold;
      font-size: 1.5rem;
      padding: 15px 0;
      font-family: inherit;
    }

    .logo img {
      height: 40px;
      margin-right: 10px;
    }

    .menu-toggle {
      display: none;
      background: none;
      border: none;
      color: var(--branco);
      font-size: 1.5rem;
      cursor: pointer;
    }

    .menu-items {
      display: flex;
      list-style: none;
      margin: 0;
      padding: 0;
    }

    .menu-items li {
      position: relative;
    }

    .menu-items a {
      color: var(--branco);
      text-decoration: none;
      padding: 20px 15px;
      display: block;
      font-weight: 500;
      transition: all 0.3s ease;
      position: relative;
      font-family: inherit;
    }

    .menu-items a:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }

    .menu-items a::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      width: 0;
      height: 3px;
      background: var(--branco);
      transition: all 0.3s ease;
      transform: translateX(-50%);
    }

    .menu-items a:hover::after {
      width: 80%;
    }

    .menu-items i {
      margin-right: 8px;
    }

    /* Conteúdo Principal */
    .main-content {
      padding-top: 80px;
      padding-bottom: 60px;
    }

    /* Container flexível e animações */
    .container-wrapper {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 30px;
      margin: 40px auto;
      max-width: 1400px;
      transition: 
        background-color 0.3s ease, 
        transform 0.2s ease, 
        box-shadow 0.3s ease, 
        filter 0.3s ease;
      box-shadow: 0 4px 6px rgba(0,0,0,0.9);
      animation: fadeIn 0.6s ease-in-out;
    }

    .container {
      flex: 1 1 400px;
      max-width: 500px;
      background-color: rgba(255, 255, 255, 0.85);
      border-radius: 15px;
      padding: 30px;
      box-shadow: 0 6px 10px rgba(0,0,0,0.3);
      animation: fadeIn 0.6s ease-in-out;
      transition: 
        background-color 0.3s ease, 
        transform 0.2s ease, 
        box-shadow 0.3s ease, 
        filter 0.3s ease;
    }

    /* Responsividade */
    @media (max-width: 768px) {
      .menu-toggle {
        display: block;
      }

      .menu-items {
        position: fixed;
        top: 70px;
        left: -100%;
        width: 80%;
        height: calc(100vh - 70px);
        background-color: var(--verde-escuro);
        flex-direction: column;
        transition: all 0.5s ease;
        box-shadow: 2px 0 5px var(--sombra);
      }

      .menu-items.active {
        left: 0;
      }

      .menu-items li {
        width: 100%;
      }

      .menu-items a {
        padding: 15px 20px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      }

      .main-content {
        padding-top: 70px;
      }

      .container {
        margin: 15px;
        padding: 20px;
      }

      form {
        padding: 20px 25px;
        margin: 20px;
      }
      button {
        width: 100%;
        margin: 10px 0 0 0;
        border-radius: 12px;
      }
      .btn01 {
        margin-left: 0;
      }
      .btn-container {
        display: flex;
        flex-direction: column;
        align-items: center;
      }
    }
    .main-content {
  padding-top: 80px; /* já tá, pode aumentar */
  padding-bottom: 60px;
}

  </style>
</head>
<body>

<header class="header">
    <div class="nav-container">
      <a href="<?=base_url('cliente/index')?>" class="logo">
        <i data-lucide="leaf"></i> Artesana
      </a>
      
      <button class="menu-toggle" id="menuToggle">
        <i data-lucide="menu"></i>
      </button>
      
      <ul class="menu-items" id="menuItems">
        <li><a href="<?=base_url('cliente/index')?>"><i data-lucide="home"></i> Início</a></li>
        <li><a href="<?=base_url('cliente/sobre')?>"><i data-lucide="info"></i> Sobre</a></li>
        <li><a href="<?=base_url('cliente/serviços')?>"><i data-lucide="briefcase"></i> Serviços</a></li>
        <li><a href="<?=base_url('cliente/produtos')?>"><i data-lucide="shopping-bag"></i> Produtos</a></li>
        <li><a href="<?=base_url('cliente/contato')?>"><i data-lucide="mail"></i> Contato</a></li>
      </ul>
    </div>
  </header>
<div class="main-content">
  <form id="pedidoForm" action="<?= base_url('cliente/confirmarPedido') ?>" method="post">

    <h2>Dados de confirmação de compra</h2>

    <label for="nome">Nome completo:</label>
    <input type="text" id="nome" name="nome" required />

    <label for="telefone">Telefone:</label>
    <input type="tel" id="telefone" name="telefone" required placeholder="(99) 99999-9999" />

    <label for="email">E-mail:</label>
    <input type="email" id="email" name="email" required placeholder="exemplo@gmail.com" />

    <label for="cep">CEP:</label>
    <input type="text" id="cep" name="cep" required />

    <label for="rua">Rua / Avenida:</label>
    <input type="text" id="rua" name="rua" required />

    <label for="numero">Número:</label>
    <input type="text" id="numero" name="numero" required placeholder="Numero da rua" />

    <label for="complemento">Complemento:</label>
    <input type="text" id="complemento" name="complemento" placeholder="(campo opcional)" />

    <label for="bairro">Bairro:</label>
    <input type="text" id="bairro" name="bairro" required />

    <label for="cidade">Cidade:</label>
    <input type="text" id="cidade" name="cidade" required />

    <label for="estado">Estado (UF):</label>
    <select id="estado" name="estado" required>
      <option value="" disabled selected>Selecione um estado</option>
      <option value="AC">Acre</option>
      <option value="AL">Alagoas</option>
      <option value="AP">Amapá</option>
      <option value="AM">Amazonas</option>
      <option value="BA">Bahia</option>
      <option value="CE">Ceará</option>
      <option value="DF">Distrito Federal</option>
      <option value="ES">Espírito Santo</option>
      <option value="GO">Goiás</option>
      <option value="MA">Maranhão</option>
      <option value="MT">Mato Grosso</option>
      <option value="MS">Mato Grosso do Sul</option>
      <option value="MG">Minas Gerais</option>
      <option value="PA">Pará</option>
      <option value="PB">Paraíba</option>
      <option value="PR">Paraná</option>
      <option value="PE">Pernambuco</option>
      <option value="PI">Piauí</option>
      <option value="RJ">Rio de Janeiro</option>
      <option value="RN">Rio Grande do Norte</option>
      <option value="RS">Rio Grande do Sul</option>
      <option value="RO">Rondônia</option>
      <option value="RR">Roraima</option>
      <option value="SC">Santa Catarina</option>
      <option value="SP">São Paulo</option>
      <option value="SE">Sergipe</option>
      <option value="TO">Tocantins</option>
    </select>

    <label for="referencia">Ponto de referência:</label>
    <input type="text" id="referencia" name="referencia" placeholder="(campo opcional)" />

    <label for="observacoes">Comentário:</label>
    <textarea id="observacoes" name="observacoes" rows="4" placeholder="(campo opcional)"></textarea>

    <div id="passwordHelpBlock" class="form-text">
      <strong>Observação:</strong> Após a confirmação de compra seu peddido pode chegar em até 7 dias úteis, exceto em <strong>FERIADOS</strong>.
    </div>

    <div class="btn-container">
      <button type="submit" class="btn00" id="btnConfirmar">Confirmar</button>
      <button type="reset" class="btn01" id="btnCancelar">Cancelar</button>
    </div>
  </form>
</div>
  <script>
    // Menu toggle mobile
    const menuToggle = document.getElementById('menuToggle');
    const menuItems = document.getElementById('menuItems');

    menuToggle.addEventListener('click', () => {
      menuItems.classList.toggle('active');
    });
  </script>
</body>
</html>