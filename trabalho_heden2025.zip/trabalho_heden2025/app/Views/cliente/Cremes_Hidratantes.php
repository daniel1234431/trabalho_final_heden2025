<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Barra de Pesquisa + Galeria</title>
  <style>
    
 
    .st {
  width: 250px;
  height: 250px;
  object-fit: cover;
  border-radius: 15px;
  margin-top: 20px;
  font-weight: bold;
  transition: 
    background-color 0.3s ease, 
    transform 0.2s ease, 
    box-shadow 0.3s ease, 
    filter 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.9);
  animation: fadeIn 0.6s ease-in-out;
}
body {
  font-family: Arial, sans-serif;
  padding: 20px;
  background-color: #f0fff4; /* ou qualquer cor que preferir */
  color: #424242;
  transition: opacity 0.9s ease;
}


#searchInput {
  width: 300px;
  padding: 8px;
  font-size: 10px;
  border: 1px solid #81C784;
  border-radius: 8px;
  background-color: #F5F5F5;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.9);
  font-weight: bold;
  transition: 
    background-color 0.3s ease, 
    transform 0.2s ease, 
    box-shadow 0.3s ease, 
    filter 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.9);
  animation: fadeIn 0.6s ease-in-out;
}

ul {
  margin-top: 10px;
  border-radius: 30px;
  font-weight: bold;
}

li {
  margin: 5px 0;
}

.div4 {
  position: fixed;
  top: 9px;
  left: 12px;
  background-color:white;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 15px;
  z-index: 1000;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.9);
  border-radius: 8px;
  font-weight: bold;
  transition: 
    background-color 0.3s ease, 
    transform 0.2s ease, 
    box-shadow 0.3s ease, 
    filter 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.9);
  animation: fadeIn 0.6s ease-in-out;
 
}

.ps {
  color:black;
  font-size: 22px;
  margin: 0;
}
.div4 h2 {
  margin-right: 10px;
}

.li1 a {
  text-decoration: none;
  color: #2E7D32;
  padding: 5px 10px;
  border-radius: 4px;
  transition: background-color 0.3s;
}

.li1 a:hover {
  background-color:black;
}

.topo {
  
  background: linear-gradient(90deg, #2E7D32, #81C784); /* Degradê verde sustentável */
  display: flex;
  justify-content: space-around;
  align-items: center;
  padding: 7px;
  width: 100%;
  z-index: 1000;
  font-weight: bold;
  box-shadow: 0 4px 6px rgba(0,0,0,0.3);
  animation: fadeIn 0.6s ease-in-out;
  transition: 
    background-color 0.3s ease, 
    transform 0.2s ease, 
    box-shadow 0.3s ease, 
    filter 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.9);
  animation: fadeIn 0.6s ease-in-out;
  
}

.topo li a {
  color: #ffffff;
  text-decoration: none;
  font-weight: bold;
  padding: 10px 16px;
  border-radius: 6px;
  transition: background-color 0.3s ease;
}

.topo li a:hover {
  background-color: #81C784;
  display: inline-block;
  text-decoration: none;
  color: white;
  background: linear-gradient(45deg, var(--verde-esmeralda), var(--verde-principal));
  padding: 12px 25px;
  border-radius: 8px;
  font-size: 16px;
  font-weight: bold;
  transition: 
    background-color 0.3s ease, 
    transform 0.2s ease, 
    box-shadow 0.3s ease, 
    filter 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.9);
  animation: fadeIn 0.6s ease-in-out;
}

.galeria {
  
  background-color:transparent;
  display: flex;
  flex-wrap: wrap;
  gap: 30px;
  justify-content: center;
  margin-top: 40px;
  padding: 20px;
  transition: 
    background-color 0.3s ease, 
    transform 0.2s ease, 
    box-shadow 0.3s ease, 
    filter 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.9);
  animation: fadeIn 0.6s ease-in-out;
  
  
}

.imagem-container1 {
  margin-bottom: 20px;
  border: 2px solid #A5D6A7;
  padding: 20px;
  background-color:transparent;
  border-radius: 15px;
  width: 400px;
  text-align: center;
  font-weight: bold;
  transition: 
    background-color 0.3s ease, 
    transform 0.2s ease, 
    box-shadow 0.3s ease, 
    filter 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.9);
  animation: fadeIn 0.6s ease-in-out;
  
}

.imagem-container1 p {
  margin-top: 8px;
  font-size: 14px;
}
.produto-img {
  width: 100%;
  max-width: 250px;
  height: 250px;
  object-fit: cover;
  border-radius: 15px;
  margin-top: 20px;
}


.img1 { border: 2px solid #A5D6A7; }
.img2 { border: 2px solid #81C784; }
.img3 { border: 2px solid #66BB6A; }



.cart-button button {
  background-color:#014421;
  color: white;
  padding: 8px 15px;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-weight: bold;
}

.search-button {
  position: absolute;
  top: 50%;
  left: 10px;
  transform: translateY(-50%);
  background: transparent;
  border: none;
  cursor: pointer;
}
.search-button i {
  font-size: 18px;
  color: #555; /* Cor do ícone */
}

.linkt {
  font-family: 'Montserrat', sans-serif;
    font-weight: 700;
    font-size: 1em;
  text-decoration: none;
  color:white;
  font-weight: bold;
  padding: 5px 10px;
}

.linkt:hover {
  color:black;
  
  border-radius: 4px;
}



.cart-icon {
  font-size: 20px;
  margin-right: 5px;
}

.cart-button {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 10px;
}
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
@media (max-width: 500px) {
  .container, .container1 {
    padding: 20px;
  }

  .button-container a {
    width: 100%;
    padding: 12px 0;
    background-color: #2E7D32;
  }
}

.btn.btn-secondary.dropdown-toggle {
  background-color:	
#014421;
  color:white;
  border: none;
  padding: 10px 20px;
  border-radius: 10px;
  cursor: pointer;
  font-weight: bold;
  transition: 
    background-color 0.3s ease, 
    transform 0.2s ease, 
    box-shadow 0.3s ease, 
    filter 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.9);
  animation: fadeIn 0.6s ease-in-out;
}
.imagem-container1 p {
  font:bold;
  color: black;
}
.elevate {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.elevate:hover {
  transform: translateY(-10px);
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
}
.eleva {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.eleva:hover {
  transform: translateY(-6px);
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.9);
}

  </style>
</head>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title> Galeria</title>
  <style>
   
  </style>
</head>
<body>


<div class="drop" data-bs-theme="dark" style="position: fixed; top: 10px; right: 10px; z-index: 1000;">
  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButtonDark" data-bs-toggle="dropdown" aria-expanded="false">
    <span class="cart-icon"><i class="fas fa-shopping-cart"></i></span>
    <span class="cart-text">Ir para:</span>
  </button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenuButtonDark">
    <li><a class="dropdown-item active" href="<?= base_url('cliente/carrinho') ?>">Carrinho</a></li>
    <li><a class="dropdown-item" href="<?= base_url('cliente/historico ') ?>">Historico</a></li>
    <li><a class="dropdown-item" href="<?= base_url('cliente/loja ') ?>">inicio</a></li>
  </ul>
</div>
<br>
<br>





<div class="div4">
  <h2 class="ps">Pesquisar itens</h2>
  <div class="eleva">
  <div class="search-container">
    <input class="pesquisa" type="text" id="searchInput" placeholder="Digite para buscar...">
    <button type="submit" class="search-button">
      <i class="fa fa-search"></i> <!-- ícone da lupa -->
    </button>
  </div>
</div>
</div>

<ul id="itemList">
  <ul class="topo">
    <li><a class="linkt" href="<?= base_url('cliente/perfumes') ?>">Perfumes</a></li>
    <li><a class="linkt" href="<?= base_url('cliente/roupas') ?>">Roupas</a></li>
    <li><a class="linkt" href="<?= base_url('cliente/sabonetes') ?>">Sabonetes</a></li>
    <li><a class="linkt" href="<?= base_url('cliente/esfoliantes') ?>">Esfoliantes</a></li>
    <li><a class="linkt" href="<?= base_url('cliente/cremes_hidratantes') ?>">Cremes/Hidratantes</a></li>
  </ul>
</ul>

<div class="galeria">
<div class="elevate">
  <div class="imagem-container1">
    <img src="/creme1.webp" alt="Produto 1" class="produto-img img1">
    <p class="linkt">Baobá – Creme para as Mãos Lavanda & Palmarosa</p>
    <p class="linkt">R$ 29,90</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/41') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>
</div>
<div class="elevate">
  <div class="imagem-container1">
    <img src="/creme2.webp" alt="Produto 2" class="produto-img img2">
    <p class="linkt">Baobá – Hidratante Corporal Lavanda</p>
    <p class="linkt">R$ 39,90</p>
    <p class="linkt"></p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/42') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>
</div>
<div class="elevate">
  <div class="imagem-container1">
    <img src="/creme3.jpeg" alt="Produto 3" class="produto-img img3">
    <p class="linkt">Creme Breylee Tratamento Acne E Espinhas Face 20g Anti-acne </p>
    <p class="linkt">R$ 59,90</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/43') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>
</div>
<div class="elevate">
<div class="elevate">
  <div class="imagem-container1">
    <img src="/creme4.webp" alt="Produto 4" class="produto-img img4">
    <p class="linkt">Chlorophylla – Hidratante Corporal Antioxidante + Nutritivo Frutas Verdes</p>
    <p class="linkt">R$ 49,90</p>
    <p class="linkt"></p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/44') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>
</div>
</div>

<div class="galeria">
<div class="elevate">
  <div class="imagem-container1">
    <img src="/creme5.jpeg" alt="Produto 5" class="produto-img img5">
    <p class="linkt">Creme Hidratante Para Mãos Flores E Vegetais - 100g</p>
    <p class="linkt">R$ 19,90</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/45') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>
</div>
<div class="elevate">
  <div class="imagem-container1">
    <img src="/creme6.webp" alt="Produto 6" class="produto-img img6">
    <p class="linkt">BIOZENTHI ONFACE Sabonete Hidratante Facial Vegano Sem Glúten </p>
    <p class="linkt">R$ 29,90</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/46') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>
</div>
<div class="elevate">
  <div class="imagem-container1">
    <img src="/creme7.webp" alt="Produto 7" class="produto-img img7">
    <p class="linkt">Kit 2x:loção Hidratante Corporal Lavanda Baunilha Alva 250g</p>
    <p class="linkt">R$ 59,90</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/47') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>
</div>
<div class="elevate">
  <div class="imagem-container1">
    <img src="/creme8.jpeg" alt="Produto 8" class="produto-img img8">
    <p class="linkt">Hidratante 37 Fator 5 - 180 Ml </p>
    <p class="linkt">R$ 39,90</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/48') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>
</div>
</div>


<script>
  const searchInput = document.getElementById("searchInput");
  const itemList = document.getElementById("itemList").getElementsByTagName("li");

  searchInput.addEventListener("keyup", function() {
    const filter = searchInput.value.toLowerCase();

    for (let i = 0; i < itemList.length; i++) {
      const itemText = itemList[i].textContent.toLowerCase();
      itemList[i].style.display = itemText.includes(filter) ? "" : "none";
    }
  });
</script>




</body>
</html>











