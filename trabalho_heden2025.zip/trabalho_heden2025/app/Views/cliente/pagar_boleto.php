<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Gerador de Boleto Simples</title>
  <style>
    :root {
      --cor-primaria: #2c3e50;
      --cor-secundaria: #3498db;
      --cor-sucesso: #27ae60;
      --cor-fundo: #f4f6f8;
      --cor-boleto: #ffffff;
      --borda-boleto: #cccccc;
      --fonte: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    body {
      font-family: var(--fonte);
      margin: 0;
      padding: 0;
      background-color: var(--cor-fundo);
    }

    .container {
      max-width: 700px;
      margin: 40px auto;
      padding: 20px;
      background-color: var(--cor-boleto);
      border-radius: 10px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
    }

    h1, h2 {
      color: var(--cor-primaria);
      text-align: center;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 15px;
      margin-top: 20px;
    }

    label {
      font-weight: 600;
      color: #333;
    }

    input, button {
      padding: 12px;
      font-size: 16px;
      border-radius: 6px;
      border: 1px solid #ccc;
      transition: border-color 0.2s, box-shadow 0.2s;
    }

    input:focus {
      border-color: var(--cor-secundaria);
      box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
      outline: none;
    }

    button {
      background-color: var(--cor-sucesso);
      color: white;
      font-weight: bold;
      cursor: pointer;
      border: none;
      transition: background-color 0.3s ease;
    }

    button:hover {
      background-color: #219150;
    }

    .boleto {
      margin-top: 30px;
      padding: 25px;
      border: 1px solid var(--borda-boleto);
      border-radius: 10px;
      background-color: #fff;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
      display: none;
    }

    .boleto p {
      margin: 10px 0;
      font-size: 16px;
      color: #333;
    }

    .codigo-barras {
      font-family: 'Courier New', Courier, monospace;
      background: #eee;
      padding: 10px;
      display: inline-block;
      border-radius: 5px;
      letter-spacing: 2px;
    }

    @media (max-width: 600px) {
      .container {
        margin: 20px;
        padding: 15px;
      }

      input, button {
        font-size: 15px;
      }
    }
    .btn-voltar {
      background-color: #4CAF50;
      color: white;
      border: none;
      padding: 10px 15px;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
      transition: background-color 0.3s, transform 0.3s, box-shadow 0.3s;
    }

  .btn-info {
    background-color: #3498db;
    color: white;
    padding: 10px 15px;
    text-decoration: none;
    border-radius: 5px;
    font-weight: bold;
    transition: background-color 0.3s;
  }

  .btn-info:hover {
    background-color: #2980b9;
  }
  </style>
</head>
<body>
  <br>
  
<div class="btvolt">
    <?= anchor('Cliente/pagar', '← Voltar', ['class' => 'btn btn-info']) ?>
</div>
  <div class="container">
    <h1>Preencha os campos para gerar o boleto</h1>

    <form id="form-boleto">
      <label>Nome do cliente:</label>
      <input type="text" id="nome" required />

      <label>CPF:</label>
      <input type="text" id="cpf" required />

      <label>Valor (R$):</label>
      <input type="number" id="valor" step="0.01" required />

      <label>Data de vencimento:</label>
      <input type="date" id="vencimento" required />

      <button type="submit">Gerar Boleto</button>
    </form>

    <div class="boleto" id="boleto-gerado">
      <h2>Boleto</h2>
      <p><strong>Beneficiário:</strong> Loja Exemplo Ltda - CNPJ: 00.000.000/0001-00</p>
      <p><strong>Pagador:</strong> <span id="boleto-nome"></span></p>
      <p><strong>CPF:</strong> <span id="boleto-cpf"></span></p>
      <p><strong>Valor:</strong> R$ <span id="boleto-valor"></span></p>
      <p><strong>Vencimento:</strong> <span id="boleto-vencimento"></span></p>
      <p><strong>Linha Digitável:</strong><br> <span class="codigo-barras">00190.00009 01234.567891 23456.789012 3 87650000000000</span></p>
      <p><strong>Instruções:</strong> Não receber após 5 dias do vencimento. Multa de 2%.</p>
    </div>
  </div>

  <script>
    const form = document.getElementById('form-boleto');
    const boleto = document.getElementById('boleto-gerado');

    form.addEventListener('submit', function(event) {
      event.preventDefault();

      document.getElementById('boleto-nome').innerText = document.getElementById('nome').value;
      document.getElementById('boleto-cpf').innerText = document.getElementById('cpf').value;
      document.getElementById('boleto-valor').innerText = parseFloat(document.getElementById('valor').value).toFixed(2);
      document.getElementById('boleto-vencimento').innerText = document.getElementById('vencimento').value;

      boleto.style.display = 'block';
    });
  </script>

</body>
</html>
