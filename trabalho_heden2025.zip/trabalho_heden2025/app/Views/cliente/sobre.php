<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Sobre Nós</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f9f9f9;
      color: #333;
    }

   
header {
  background-color: #2E7D32;
  padding: 20px;
  text-align: center;
  color: white;
}

header nav a {
  color: white;
  margin: 0 15px;
  text-decoration: none;
  font-weight: bold;
}

header nav a:hover {
  text-decoration: underline;
}

    main {
      max-width: 800px;
      margin: 40px auto;
      padding: 20px;
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h1, h2 {
      color: #004aad;
    }

    p {
      line-height: 1.6;
    }

    footer {
      background-color: #eee;
      text-align: center;
      padding: 10px;
      font-size: 0.9em;
      color: #666;
    }
  </style>
</head>
<body>

<header>
    <h1>Sobre nós</h1>
    <nav>
      <a href="<?=base_url('cliente/index')?>">Início</a>
      <a href="<?=base_url('cliente/sobre')?>">Sobre</a>
      <a href="<?=base_url('cliente/serviços')?>">Serviços</a>
      <a href="<?=base_url('cliente/contato')?>">Contato</a>
    </nav>
  </header>

  <main>
    <h2>Quem Somos</h2>
    <p>Somos uma equipe dedicada a venda de produtos sustentaveis e focados na preservação do meio-ambiente. Nosso objetivo é ultilizar ao máximo produtos que.</p>

    <h2>Nossa Missão</h2>
    <p>Oferecer produtos e serviços de qualidade, com foco em inovação, usabilidade e satisfação do cliente.</p>

    <h2>História</h2>
    <p>Fundada em 2025,. Desde então, crescemos e nos tornamos referência em .</p>
  </main>

  <footer>
   
  </footer>

</body>
</html>