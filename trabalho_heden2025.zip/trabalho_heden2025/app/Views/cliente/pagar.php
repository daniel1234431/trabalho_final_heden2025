<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <title>Formas de Pagamento</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #d0f0c0, #e5f9e0);
      margin: 0;
      padding: 40px 20px;
      text-align: center;
      color: #1b5e20;
    }

    h1 {
      font-size: 40px;
      margin-bottom: 40px;
      font-weight: 700;
      color: #2e7d32;
      text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.3);
    }

    .formas-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 20px;
      max-width: 900px;
      margin: 0 auto;
      padding: 0 10px;
    }

    .forma-linha {
    width: 280px;
    min-height: 680px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center; 
    background-color: #ffffff;
    border: 1px solid #a5d6a7;
    border-radius: 12px;
    padding: 40px 20px; 
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: transform 0.2s ease, box-shadow 0.3s ease;
    text-align: center;
}
.button-container {
  margin-top: 30px;
}


    .forma-linha:hover {
      transform: translateY(-3px);
      box-shadow: 0 6px 16px rgba(0, 0, 0, 0.15);
    }

    .forma p {
      margin: 0;
      font-size: 40px;
      font-weight: 500;
      color: #2e7d32;
    }

    .btn-pagar,
.btn-voltar {
  background-color: #43a047;
  color: white;
  padding: 14px 28px;  
  border-radius: 8px;
  text-decoration: none;
  font-weight: 600;
  font-size: 17px; 
  border: none;
  cursor: pointer;
  transition: background-color 0.3s ease, transform 0.2s ease;
  margin-top: 15px;
}


    .btn-pagar:hover,
    .btn-voltar:hover {
      background-color: #2e7d32;
      transform: scale(1.05);
    }

    .btn-voltar {
      margin-top: 50px;
      display: inline-block;
    }

    @media (max-width: 600px) {
      .forma-linha {
        width: 100%;
      }
    }
  </style>
</head>
<body>
  <h1>Escolha a Forma de Pagamento</h1>

  <div class="formas-container">
    <div class="forma-linha">
      <div class="forma">
        <p>💳 Cartão de Crédito</p>
      </div>
      <div class="button-container">
        <?= anchor('Cliente/pagar_cartao', 'Pagar', ['class' => 'btn-pagar']) ?>
      </div>
    </div>

    <div class="forma-linha">
      <div class="forma">
        <p>🏦 Boleto Bancário</p>
      </div>
      <div class="button-container">
        <?= anchor('Cliente/pagar_boleto', 'Pagar', ['class' => 'btn-pagar']) ?>
      </div>
    </div>

    <div class="forma-linha">
      <div class="forma">
        <p>💸 PIX</p>
      </div>
      <div class="button-container">
        <?= anchor('Cliente/pagar_pix', 'Pagar', ['class' => 'btn-pagar']) ?>
      </div>
    </div>
  </div>

  <a href="<?= base_url('cliente/loja') ?>" class="btn-voltar">Voltar para a loja</a>
</body>
</html>