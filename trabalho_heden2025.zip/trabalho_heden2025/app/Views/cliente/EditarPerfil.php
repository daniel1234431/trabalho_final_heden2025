<?php
session_start();
// Exemplo: recupera o nome da foto atual salva na sessão ou banco
$fotoAtual = $_SESSION['usuario']['foto'] ?? 'default.png';
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Editar Foto de Perfil</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #e8f5e9;
            margin: 0;
            padding: 40px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .container {
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            width: 400px;
            text-align: center;
        }
        .foto-perfil {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #4caf50;
            margin-bottom: 20px;
        }
        input[type="file"] {
            margin: 20px 0;
        }
        button {
            background-color: #4caf50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }
        button:hover {
            background-color: #388e3c;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Editar Foto de Perfil</h2>
    <img src="uploads/<?= htmlspecialchars($fotoAtual) ?>" alt="Foto atual" class="foto-perfil">
    
    <form action="salvar_foto.php" method="post" enctype="multipart/form-data">
        <input type="file" name="nova_foto" accept="image/*" required><br>
        <button type="submit">Salvar Nova Foto</button>
    </form>
</div>

</body>
</html>
