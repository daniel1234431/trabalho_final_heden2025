<!DOCTYPE html>
<html lang="pt-br">
<head>
  <!-- Meta tags básicas -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <!-- Título da aba -->
  <title>Artesana</title>

  <!-- Ícones Lucide -->
  <script src="https://unpkg.com/lucide@latest"></script>

  <style>
    /* Variáveis de cor */
    :root {
      --verde-esmeralda: #43A047;
      --verde-principal: #2E7D32;
      --verde-escuro: #014421;
      --branco: #FFFFFF;
      --sombra: rgba(0,0,0,0.2);
    }

    
    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      25% { transform: translateX(-5px); }
      75% { transform: translateX(5px); }
    }

    
    @keyframes slideDown {
      from { transform: translateY(-100%); }
      to { transform: translateY(0); }
    }

    /* Reset e base do body */
    html, body {
      min-height: 100vh;
      height: 100%;
      margin: 0;
      padding: 0;
    }

    body {  
      background-color: #dbece6;
      color: #424242;
      font-family: Arial, sans-serif;
      padding: 20px;
    }

    /* Cabeçalho fixo com fundo escuro */
    .header {
      background-color: var(--verde-escuro);
      position: fixed;
      top: 0;
      width: 100%;
      z-index: 1000;
      box-shadow: 0 4px 12px var(--sombra);
      animation: slideDown 0.5s ease-out;
    }

    /* Container da navegação */
    .nav-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 20px;
      max-width: 1400px;
      margin: 0 auto;
    }

    /* Logo */
    .logo {
      display: flex;
      align-items: center;
      color: var(--branco);
      text-decoration: none;
      font-weight: bold;
      font-size: 1.5rem;
      padding: 15px 0;
    }

    .logo img {
      height: 40px;
      margin-right: 10px;
    }

    /* Botão do menu responsivo */
    .menu-toggle {
      display: none;
      background: none;
      border: none;
      color: var(--branco);
      font-size: 1.5rem;
      cursor: pointer;
    }

    /* Itens do menu */
    .menu-items {
      display: flex;
      list-style: none;
      margin: 0;
      padding: 0;
    }

    .menu-items li {
      position: relative;
    }

    .menu-items a {
      color: var(--branco);
      text-decoration: none;
      padding: 20px 15px;
      display: block;
      font-weight: 500;
      transition: all 0.3s ease;
      position: relative;
    }

    .menu-items a:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }

    .menu-items a::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      width: 0;
      height: 3px;
      background: var(--branco);
      transition: all 0.3s ease;
      transform: translateX(-50%);
    }

    .menu-items a:hover::after {
      width: 80%;
    }

    /* Ícones no menu */
    .menu-items i {
      margin-right: 8px;
    }

    /* Conteúdo principal com espaçamento abaixo do menu */
    .main-content {
      padding-top: 80px;
      padding-bottom: 60px;
    }

    /* Wrapper para os containers centrais */
    .container-wrapper {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 30px;
      margin: 40px auto;
      max-width: 1400px;
      box-shadow: 0 4px 6px rgba(0,0,0,0.9);
      animation: fadeIn 0.6s ease-in-out;
    }

    /* Bloco de conteúdo */
    .container {
      flex: 1 1 400px;
      
      background-color: rgba(255, 255, 255, 0.85);
      border-radius: 30px;
      padding: 40px;
      box-shadow: 0 6px 10px rgba(0,0,0,0.9);
      animation: fadeIn 0.6s ease-in-out;
    }

    .titulo1 {
      font-size: 24px;
      color: var(--verde-escuro);
      margin-bottom: 15px;
    }

    /* Botões estilizados */
    .btn {
      background-color: var(--verde-escuro);
      color: white;
      padding: 12px 24px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-weight: bold;
      text-decoration: none;
      display: inline-block;
      transition: all 0.3s ease;
      box-shadow: 0 4px 6px rgba(0,0,0,0.3);
      position: relative;
      overflow: hidden;
    }

    .btn:hover {
      background-color: var(--verde-esmeralda);
      transform: translateY(-3px);
      box-shadow: 0 6px 12px rgba(0,0,0,0.2);
      animation: bounce 0.5s ease;
    }

    .btn:active {
      transform: translateY(1px);
    }

    /* Campos de formulário */
    form input[type="email"],
    form input[type="text"] {
      padding: 12px;
      width: 100%;
      border-radius: 8px;
      border: 1px solid #ccc;
      margin-bottom: 15px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    /* Rodapé fixo */
    .footer {
      text-align: center;
      padding: 20px;
      font-weight: bold;
      color: white;
      background-color: var(--verde-escuro);
      border-top: 4px solid #81C784;
      animation: fadeIn 0.8s ease-in-out;
      position: fixed;
      bottom: 0;
      width: 100%;
    }

    /* Responsividade */
    @media (max-width: 768px) {
      .menu-toggle {
        display: block;
      }

      .menu-items {
        position: fixed;
        top: 70px;
        left: -100%;
        width: 80%;
        height: calc(100vh - 70px);
        background-color: var(--verde-escuro);
        flex-direction: column;
        transition: all 0.5s ease;
        box-shadow: 2px 0 5px var(--sombra);
      }

      .menu-items.active {
        left: 0;
      }

      .container {
        margin: 15px;
        padding: 20px;
      }
    }
     body {
      font-family: Arial, sans-serif;
      background: #f0f0f0;
      display: flex;
      height: 100vh;
      justify-content: center;
      align-items: center;
    }

    .login-btn {
  display: flex;
  align-items: center;
  background-color: #fff;
  border: 1px solid #ccc;
  border-radius: 50px;
  padding: 5px 10px;
  cursor: pointer;
  box-shadow: 0 2px 5px rgba(0,0,0,0.1);
  transition: background 0.3s;
}

.login-btn:hover {
  background-color: #eee;
}

.profile-pic {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  object-fit: cover;
  margin-right: 10px;
}

.login-text {
  font-size: 14px;
  color: #333;
}


  </style>
</head>

<body>

  <!-- Cabeçalho com navegação -->
  <header class="header">
    <div class="nav-container">
      <!-- Logo -->
      <a href="<?=base_url('cliente/index')?>" class="logo">
        <i data-lucide="leaf"></i> Artesana
      </a>

      <!-- Botão do menu mobile -->
      <button class="menu-toggle" id="menuToggle">
        <i data-lucide="menu"></i>
      </button>

      <!-- Itens do menu -->
      <ul class="menu-items" id="menuItems">
      

        <li><a href="<?=base_url('cliente/index')?>"><i data-lucide="home"></i> Início</a></li>
        <li><a href="<?=base_url('cliente/sobre')?>"><i data-lucide="info"></i> Sobre</a></li>
        <li><a href="<?=base_url('cliente/serviços')?>"><i data-lucide="briefcase"></i> Serviços</a></li>
        <li><a href="<?=base_url('cliente/loja')?>"><i data-lucide="shopping-bag"></i> Produtos</a></li>
        <li><a href="<?=base_url('cliente/contato')?>"><i data-lucide="mail"></i> Contato</a></li>
        <li><a href="<?=base_url('cliente/meusPedidos')?>"><i data-lucide="mail"></i>Minhas compras</a></li>
        
       
        <li>
  <a href="<?= base_url('cliente/MeuPerfil') ?>">
    <i data-lucide="user"></i> Meu Perfil
  </a>
</li>





      </ul>
    </div>
  </header>

  <!-- Conteúdo Principal -->
  <div class="main-content">
    <div class="container-wrapper">
      
    <div class="container">
        <h1 class="titulo1">Bem-vindo à Artesana!</h1>
        <p>Conheça os melhores produtos artesanais do Brasil. Produzidos com carinho, visando a qualidade e valorizando a sustentabilidade do planeta.</p>
        <div class="button-container">
          <?= anchor('Cliente/cadastro', 'Cadastre-se', ['class' => 'btn', 'data-url' => base_url('Cliente/cadastro')]) ?>
        </div>
      </div>

      <div class="container">
        <h1 class="titulo1">Destaques do Dia</h1>
        <ul style="list-style: none; padding: 0;">
          <li><strong>Sabonetes Naturais</strong> - A partir de R$30</li>
          <li><strong>Cremes e Hidratantes</strong> - Leve 3, pague 2</li>
          <li><strong>Artesanato em Crochê</strong> - Frete grátis</li>
          <li><strong>Perfumes</strong> - A partir de R$119,99</li>
        </ul>
        <div class="button-container">
          <?= anchor('Cliente/login', 'Aproveitar', ['class' => 'btn', 'data-url' => base_url('Cliente/login')]) ?>
        </div>
      </div>

      <div class="container">
        <h1 class="titulo1">Responda as questões e ganhe 70% de desconto nas 3 primeiras compras disponiveis em até 60 dias.
          <br><br>
        </h1>
        <div class="button-container">
          <?= anchor('Cliente/questionario', 'Ver questionário', ['class' => 'btn', 'data-url' => base_url('Cliente/questionario')]) ?>
        </div>
      </div>

      <div class="container">
        <h1 class="titulo1">Receba Novidades</h1>
        <p>Cadastre seu e-mail para promoções exclusivas e novos produtos.</p>
        <form>
          <input type="email" placeholder="Seu e-mail">
          <br>
          <div class="button-container">
            <button type="submit" class="btn">Cadastrar</button>
          </div>
        </form>
      </div>

      <div class="container">
        <h1 class="titulo1">Avalie-nos</h1>
        <p>Deixe sua avaliação e nos ajude a melhorar nossos produtos e serviços.</p>
        <form>
          <input type="text" placeholder="Deixe sua avaliação">
          <br>
          <div class="button-container">
            <button type="button" class="btn">Avaliar</button>
          </div>
        </form>
      </div>
      
    </div>
    </div>
  </div>

  <!-- Rodapé -->
  <div class="footer">
    &copy; 2025 Artesana. Todos os direitos reservados.
  </div>

  <script>
   
    lucide.createIcons();

    
    const menuToggle = document.getElementById('menuToggle');
    const menuItems = document.getElementById('menuItems');
    menuToggle.addEventListener('click', () => {
      menuItems.classList.toggle('active');
      const icon = menuToggle.querySelector('i');
      icon.setAttribute('data-lucide', menuItems.classList.contains('active') ? 'x' : 'menu');
      lucide.createIcons();
    });

    
    document.querySelectorAll('.btn').forEach(btn => {
      btn.addEventListener('click', function(e) {
        const ripple = document.createElement('span');
        ripple.classList.add('ripple');
        this.appendChild(ripple);

        const rect = this.getBoundingClientRect();
        ripple.style.left = `${e.clientX - rect.left}px`;
        ripple.style.top = `${e.clientY - rect.top}px`;

        setTimeout(() => ripple.remove(), 600);

        const url = this.getAttribute('data-url');
        if (url) {
          e.preventDefault();
          document.body.style.opacity = '0';
          setTimeout(() => window.location.href = url, 300);
        }
      });
    });

   
    document.querySelectorAll('form').forEach(form => {
      form.addEventListener('submit', function(e) {
        const inputs = this.querySelectorAll('input[required]');
        let hasError = false;
        inputs.forEach(input => {
          if (!input.value) {
            input.style.borderColor = '#f44336';
            input.style.animation = 'shake 0.5s ease';
            hasError = true;
            setTimeout(() => input.style.animation = '', 500);
          }
        });
        if (hasError) e.preventDefault();
      });
    });
  </script>
</body>
</html>