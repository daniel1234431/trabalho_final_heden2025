<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Contato</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f0f4f7;
      margin: 0;
      padding: 0;
    }
    header {
      background-color: #2E7D32;
      padding: 20px;
      text-align: center;
      color: white;
    }

    header nav a {
      color: white;
      margin: 0 15px;
      text-decoration: none;
      font-weight: bold;
    }

    header nav a:hover {
      text-decoration: underline;
    }

    .container {
      max-width: 600px;
      margin: 50px auto;
      background: white;
      padding: 60px;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    h2 {
      text-align: center;
      color: #2E7D32;
    }

    form {
      display: flex;
      flex-direction: column;
    }

    label {
      margin-top: 15px;
      font-weight: bold;
      color: #555;
    }

    input, textarea {
      padding: 10px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 16px;
    }

    textarea {
      resize: vertical;
      min-height: 120px;
    }

    button {
      margin-top: 20px;
      padding: 12px;
      background-color: #2E7D32;
      color: white;
      font-size: 16px;
      font-weight: bold;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    button:hover {
      background-color: #1b5e20;
    }

    .success-message {
      margin-top: 15px;
      color: green;
      text-align: center;
      display: none;
      font-weight: bold;
    }

    @media (max-width: 640px) {
      .container {
        margin: 20px;
        padding: 20px;
      }
    }
  </style>
</head>
<body>

<header>
  <h1>Nossos Serviços</h1>
  <nav>
    <a href="<?= base_url('cliente/index') ?>">Início</a>
    <a href="<?= base_url('cliente/sobre') ?>">Sobre</a>
    <a href="<?= base_url('cliente/serviços') ?>">Serviços</a>
    <a href="<?= base_url('cliente/contato') ?>">Contato</a>
  </nav>
</header>

<div class="container">
  <h2>Fale Conosco</h2>

  <?php if (isset($validation)): ?>
    <div style="color: red; text-align: center;">
      <?= $validation->listErrors() ?>
    </div>
  <?php endif; ?>

  <form action="<?= base_url('contato/enviar') ?>" method="post">

    <label for="nome">Nome:</label>
    <input type="text" id="nome" name="nome" required>

    <label for="email">E-mail:</label>
    <input type="email" id="email" name="email" required>

    <label for="assunto">Assunto:</label>
    <input type="text" id="assunto" name="assunto" required>

    <label for="mensagem">Mensagem:</label>
    <textarea id="mensagem" name="mensagem" required></textarea>

    <button type="submit">Enviar Mensagem</button>
  </form>

  <script>
    form.addEventListener("submit", function(e) {
  e.preventDefault();
  mensagemSucesso.style.display = "block";
  form.reset();
});

  </script>
</div>

</body>
</html>